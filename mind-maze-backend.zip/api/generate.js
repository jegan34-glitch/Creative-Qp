
import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import fetch from "node-fetch";

const app = express();
app.use(cors());
app.use(express.json());

function verifyAdminToken(token) {
  try {
    return jwt.verify(token, process.env.ADMIN_MASTER_SECRET);
  } catch {
    return null;
  }
}

app.post("/api/admin/create-token", (req, res) => {
  const { adminSecret, issuedTo } = req.body;
  if (adminSecret !== process.env.ADMIN_MASTER_SECRET) {
    return res.status(403).json({ error: "Unauthorized" });
  }

  const token = jwt.sign(
    { issuedTo, role: "staff" },
    process.env.ADMIN_MASTER_SECRET,
    { expiresIn: `${process.env.TOKEN_EXPIRY_MINUTES || 60}m` }
  );

  res.json({ token, expiresInMinutes: process.env.TOKEN_EXPIRY_MINUTES || 60 });
});

app.post("/api/generate", async (req, res) => {
  const token = req.headers["x-admin-token"];
  if (!token) return res.status(401).json({ error: "Missing token" });

  const decoded = verifyAdminToken(token);
  if (!decoded) return res.status(403).json({ error: "Invalid or expired token" });

  const { classLevel, subject, topic, count } = req.body;

  const prompt = `Generate ${count} CBSE-level Mind Maze questions for Class ${classLevel}, Subject ${subject}, Topic ${topic}.
Return STRICT JSON:
{ "questions": [ { "id":1, "type":"", "difficulty":"A|B|C", "prompt":"", "guide":"" } ] }`;

  try {
    const aiRes = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-5.1",
        input: prompt,
        temperature: 0.3,
        max_output_tokens: 1200,
      }),
    });

    if (!aiRes.ok) return res.status(500).json({ error: "OpenAI error" });

    const json = await aiRes.json();
    const text = json.output_text || json.output?.[0]?.content?.[0]?.text;
    const parsed = JSON.parse(text);
    res.json(parsed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI generation failed" });
  }
});

export default app;
