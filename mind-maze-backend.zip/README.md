
Mind Maze Backend (Vercel Ready)

1. Upload this folder to GitHub
2. Import into Vercel
3. Set Environment Variables:
   - OPENAI_API_KEY
   - ADMIN_MASTER_SECRET
   - TOKEN_EXPIRY_MINUTES

Endpoints:
POST /api/admin/create-token
POST /api/generate
